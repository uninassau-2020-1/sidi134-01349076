export interface Cep {
  cep: number,
  logradouro?: string,
  complemento?: string,
  bairro?: string,
  localidade?: string,
  uf?: string,
}